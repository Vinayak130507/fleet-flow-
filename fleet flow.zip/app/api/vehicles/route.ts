import { NextResponse } from 'next/server';
import { db } from '@/lib/firebase';
import { collection, getDocs, setDoc, doc, orderBy, query, serverTimestamp } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '@/lib/firestore-errors';

const COLLECTION_NAME = 'vehicles';

export async function GET() {
  try {
    const q = query(collection(db, COLLECTION_NAME), orderBy('lastUpdated', 'desc'));
    const snapshot = await getDocs(q);
    const vehicles = snapshot.docs.map(doc => ({ 
      ID: doc.id, 
      ...doc.data() 
    })).map((v: any) => ({
      ID: v.vehicleId || v.ID,
      Type: v.type || v.Type,
      Status: v.status || v.Status
    }));
    return NextResponse.json(vehicles);
  } catch (error: any) {
    try {
      handleFirestoreError(error, OperationType.LIST, COLLECTION_NAME);
    } catch (e: any) {
      return NextResponse.json(JSON.parse(e.message), { status: 500 });
    }
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const docId = body.ID;
    const vehicleData = {
      vehicleId: body.ID,
      type: body.Type,
      status: body.Status,
      lastUpdated: serverTimestamp(),
    };
    await setDoc(doc(db, COLLECTION_NAME, docId), vehicleData);
    return NextResponse.json({ id: docId, ...vehicleData }, { status: 201 });
  } catch (error: any) {
    try {
      handleFirestoreError(error, OperationType.WRITE, COLLECTION_NAME);
    } catch (e: any) {
      return NextResponse.json(JSON.parse(e.message), { status: 400 });
    }
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
}
