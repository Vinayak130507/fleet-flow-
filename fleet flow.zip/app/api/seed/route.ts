import { NextResponse } from 'next/server';
import { db } from '@/lib/firebase';
import { collection, getDocs, query, limit, doc, setDoc, addDoc, serverTimestamp } from 'firebase/firestore';

export async function GET() {
  try {
    const vehiclesCol = collection(db, 'vehicles');
    const qr = query(vehiclesCol, limit(1));
    const snapshot = await getDocs(qr);
    
    if (!snapshot.empty) {
      return NextResponse.json({ message: 'Database already seeded' });
    }

    const vehicles = [
      { vehicleId: 'TRK-001', type: 'Truck', status: 'On Trip', lastUpdated: serverTimestamp() },
      { vehicleId: 'VAN-042', type: 'Van', status: 'Available', lastUpdated: serverTimestamp() },
      { vehicleId: 'TRK-005', type: 'Truck', status: 'In Shop', lastUpdated: serverTimestamp() },
      { vehicleId: 'BKE-012', type: 'Bike', status: 'Available', lastUpdated: serverTimestamp() },
      { vehicleId: 'TRK-009', type: 'Truck', status: 'On Trip', lastUpdated: serverTimestamp() },
    ];

    for (const v of vehicles) {
      await setDoc(doc(db, 'vehicles', v.vehicleId), v);
    }

    const trips = [
      { tripId: 'TRP-101', destination: 'Mumbai', status: 'In Transit', createdAt: serverTimestamp() },
      { tripId: 'TRP-102', destination: 'Delhi', status: 'Pending', createdAt: serverTimestamp() },
      { tripId: 'TRP-103', destination: 'Bangalore', status: 'Loading', createdAt: serverTimestamp() },
    ];

    for (const t of trips) {
      await setDoc(doc(db, 'trips', t.tripId), t);
    }

    const drivers = [
      { name: 'Amit K.', licenseStatus: 'Valid', status: 'On Duty' },
      { name: 'Rahul S.', licenseStatus: 'Expiring Soon', status: 'Off Duty' },
      { name: 'Sarah J.', licenseStatus: 'Valid', status: 'On Duty' },
    ];

    for (const d of drivers) {
      await addDoc(collection(db, 'drivers'), d);
    }

    const maintenance = [
      { vehicleId: 'TRK-001', serviceType: 'Oil Change', cost: 12500, date: serverTimestamp() },
    ];

    for (const m of maintenance) {
      await addDoc(collection(db, 'maintenance'), m);
    }

    const fuelLogs = [
      { vehicleId: 'VAN-042', liters: 45, cost: 4200, date: serverTimestamp() },
    ];

    for (const f of fuelLogs) {
      await addDoc(collection(db, 'fuelLogs'), f);
    }

    return NextResponse.json({ message: 'Database seeded successfully' });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
