import { NextResponse } from 'next/server';
import { db } from '@/lib/firebase';
import { collection, getDocs, addDoc, orderBy, query, serverTimestamp } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '@/lib/firestore-errors';

const COLLECTION_NAME = 'maintenance';

export async function GET() {
  try {
    const q = query(collection(db, COLLECTION_NAME), orderBy('date', 'desc'));
    const snapshot = await getDocs(q);
    const maintenance = snapshot.docs.map(doc => ({ 
      id: doc.id, 
      ...doc.data() 
    })).map((m: any) => ({
      Vehicle: m.vehicleId,
      Service: m.serviceType,
      Cost: `₹${m.cost}`
    }));
    return NextResponse.json(maintenance);
  } catch (error: any) {
    try {
      handleFirestoreError(error, OperationType.LIST, COLLECTION_NAME);
    } catch (e: any) {
      return NextResponse.json(JSON.parse(e.message), { status: 500 });
    }
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const cost = parseFloat(body.Cost.toString().replace('₹', '').replace(',', ''));
    const recordData = {
      vehicleId: body.Vehicle,
      serviceType: body.Service,
      cost: cost,
      date: serverTimestamp(),
    };
    const docRef = await addDoc(collection(db, COLLECTION_NAME), recordData);
    return NextResponse.json({ id: docRef.id, ...recordData }, { status: 201 });
  } catch (error: any) {
    try {
      handleFirestoreError(error, OperationType.WRITE, COLLECTION_NAME);
    } catch (e: any) {
      return NextResponse.json(JSON.parse(e.message), { status: 400 });
    }
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
}
