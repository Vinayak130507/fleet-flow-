import { NextResponse } from 'next/server';
import { db } from '@/lib/firebase';
import { collection, getDocs, setDoc, doc, orderBy, query, serverTimestamp } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '@/lib/firestore-errors';

const COLLECTION_NAME = 'trips';

export async function GET() {
  try {
    const q = query(collection(db, COLLECTION_NAME), orderBy('createdAt', 'desc'));
    const snapshot = await getDocs(q);
    const trips = snapshot.docs.map(doc => ({ 
      id: doc.id, 
      ...doc.data() 
    })).map((t: any) => ({
      'Trip ID': t.tripId || t['Trip ID'],
      Destination: t.destination || t.Destination,
      Status: t.status || t.Status
    }));
    return NextResponse.json(trips);
  } catch (error: any) {
    try {
      handleFirestoreError(error, OperationType.LIST, COLLECTION_NAME);
    } catch (e: any) {
      return NextResponse.json(JSON.parse(e.message), { status: 500 });
    }
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const docId = body['Trip ID'];
    const tripData = {
      tripId: docId,
      destination: body.Destination,
      status: body.Status,
      createdAt: serverTimestamp(),
    };
    await setDoc(doc(db, COLLECTION_NAME, docId), tripData);
    return NextResponse.json({ id: docId, ...tripData }, { status: 201 });
  } catch (error: any) {
    try {
      handleFirestoreError(error, OperationType.WRITE, COLLECTION_NAME);
    } catch (e: any) {
      return NextResponse.json(JSON.parse(e.message), { status: 400 });
    }
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
}
