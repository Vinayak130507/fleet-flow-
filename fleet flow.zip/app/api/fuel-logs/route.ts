import { NextResponse } from 'next/server';
import { db } from '@/lib/firebase';
import { collection, getDocs, addDoc, orderBy, query, serverTimestamp } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '@/lib/firestore-errors';

const COLLECTION_NAME = 'fuelLogs';

export async function GET() {
  try {
    const q = query(collection(db, COLLECTION_NAME), orderBy('date', 'desc'));
    const snapshot = await getDocs(q);
    const logs = snapshot.docs.map(doc => ({ 
      id: doc.id, 
      ...doc.data() 
    })).map((f: any) => ({
      Vehicle: f.vehicleId,
      Liters: f.liters,
      Cost: `₹${f.cost}`
    }));
    return NextResponse.json(logs);
  } catch (error: any) {
    try {
      handleFirestoreError(error, OperationType.LIST, COLLECTION_NAME);
    } catch (e: any) {
      return NextResponse.json(JSON.parse(e.message), { status: 500 });
    }
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const cost = parseFloat(body.Cost.toString().replace('₹', '').replace(',', ''));
    const logData = {
      vehicleId: body.Vehicle,
      liters: parseFloat(body.Liters),
      cost: cost,
      date: serverTimestamp(),
    };
    const docRef = await addDoc(collection(db, COLLECTION_NAME), logData);
    return NextResponse.json({ id: docRef.id, ...logData }, { status: 201 });
  } catch (error: any) {
    try {
      handleFirestoreError(error, OperationType.WRITE, COLLECTION_NAME);
    } catch (e: any) {
      return NextResponse.json(JSON.parse(e.message), { status: 400 });
    }
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
}
