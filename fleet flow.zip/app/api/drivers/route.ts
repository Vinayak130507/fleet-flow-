import { NextResponse } from 'next/server';
import { db } from '@/lib/firebase';
import { collection, getDocs, addDoc } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '@/lib/firestore-errors';

const COLLECTION_NAME = 'drivers';

export async function GET() {
  try {
    const snapshot = await getDocs(collection(db, COLLECTION_NAME));
    const drivers = snapshot.docs.map(doc => ({ 
      id: doc.id, 
      ...doc.data() 
    })).map((d: any) => ({
      Name: d.name,
      License: d.licenseStatus,
      Status: d.status
    }));
    return NextResponse.json(drivers);
  } catch (error: any) {
    try {
      handleFirestoreError(error, OperationType.LIST, COLLECTION_NAME);
    } catch (e: any) {
      return NextResponse.json(JSON.parse(e.message), { status: 500 });
    }
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const driverData = {
      name: body.Name,
      licenseStatus: body.License,
      status: body.Status,
    };
    const docRef = await addDoc(collection(db, COLLECTION_NAME), driverData);
    return NextResponse.json({ id: docRef.id, ...driverData }, { status: 201 });
  } catch (error: any) {
    try {
      handleFirestoreError(error, OperationType.WRITE, COLLECTION_NAME);
    } catch (e: any) {
      return NextResponse.json(JSON.parse(e.message), { status: 400 });
    }
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
}
